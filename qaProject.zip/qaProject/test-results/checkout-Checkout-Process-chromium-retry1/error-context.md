# Test info

- Name: Checkout Process
- Location: C:\Users\User\Desktop\qaProject\tests\checkout.spec.ts:10:5

# Error details

```
Error: page.click: Test ended.
Call log:
  - waiting for locator('text=Sauce Labs Bike Light')

    at ProductsPage.addToCart (C:\Users\User\Desktop\qaProject\pages\ProductsPage.ts:7:21)
    at C:\Users\User\Desktop\qaProject\tests\checkout.spec.ts:19:22
```

# Test source

```ts
   1 | import { Page } from '@playwright/test';
   2 |
   3 | export class ProductsPage {
   4 |   constructor(public page: Page) {}
   5 |
   6 |   async addToCart(itemName: string) {
>  7 |     await this.page.click(`text=${itemName}`);
     |                     ^ Error: page.click: Test ended.
   8 |     await this.page.click('button:has-text("Add to cart")');
   9 |   }
  10 |
  11 |   async removeFromCart(itemName: string) {
  12 |     await this.page.click(`text=${itemName}`);
  13 |     await this.page.click('button:has-text("Remove")');
  14 |   }
  15 |
  16 |   async sortAZ() {
  17 |     await this.page.selectOption('.product_sort_container', 'az');
  18 |   }
  19 |
  20 |   async sortPriceHighToLow() {
  21 |     await this.page.selectOption('.product_sort_container', 'hilo');
  22 |   }
  23 |
  24 |   async goToCart() {
  25 |     await this.page.click('.shopping_cart_link');
  26 |   }
  27 | }
  28 |
```