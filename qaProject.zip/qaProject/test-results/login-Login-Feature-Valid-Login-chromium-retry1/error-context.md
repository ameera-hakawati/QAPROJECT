# Test info

- Name: Login Feature >> Valid Login
- Location: C:\Users\User\Desktop\qaProject\tests\login.spec.ts:8:7

# Error details

```
Error: page.goto: net::ERR_ABORTED; maybe frame was detached?
Call log:
  - navigating to "https://www.saucedemo.com/", waiting until "load"

    at LoginPage.goto (C:\Users\User\Desktop\qaProject\pages\LoginPage.ts:7:21)
    at C:\Users\User\Desktop\qaProject\tests\login.spec.ts:10:21
```

# Test source

```ts
   1 | import { Page } from '@playwright/test';
   2 |
   3 | export class LoginPage {
   4 |   constructor(public page: Page) {}
   5 |
   6 |   async goto() {
>  7 |     await this.page.goto('https://www.saucedemo.com/');
     |                     ^ Error: page.goto: net::ERR_ABORTED; maybe frame was detached?
   8 |   }
   9 |
  10 |   async login(username: string, password: string) {
  11 |     await this.page.fill('#user-name', username);
  12 |     await this.page.fill('#password', password);
  13 |     await this.page.click('#login-button');
  14 |   }
  15 | }
  16 |
```