# Test info

- Name: Login Feature >> Valid Login
- Location: C:\Users\User\Desktop\qaProject\tests\login.spec.ts:8:7

# Error details

```
Error: Timed out 5000ms waiting for expect(locator).toHaveURL(expected)

Locator: locator(':root')
Expected pattern: /inventory/
Received string:  "https://www.saucedemo.com/"
Call log:
  - expect.toHaveURL with timeout 5000ms
  - waiting for locator(':root')
    9 × locator resolved to <html lang="en">…</html>
      - unexpected value "https://www.saucedemo.com/"

    at C:\Users\User\Desktop\qaProject\tests\login.spec.ts:12:24
```

# Page snapshot

```yaml
- text: Swag Labs
- textbox "Username": User
- textbox "Password": secret_sauce
- 'heading "Epic sadface: Username and password do not match any user in this service" [level=3]':
  - button
  - text: "Epic sadface: Username and password do not match any user in this service"
- button "Login"
- heading "Accepted usernames are:" [level=4]
- text: standard_user locked_out_user problem_user performance_glitch_user error_user visual_user
- heading "Password for all users:" [level=4]
- text: secret_sauce
```

# Test source

```ts
   1 | import { test, expect } from '@playwright/test';
   2 | import { LoginPage } from '../pages/LoginPage';
   3 | import * as dotenv from 'dotenv';
   4 |
   5 | dotenv.config();
   6 |
   7 | test.describe('Login Feature', () => {
   8 |   test('Valid Login', async ({ page }) => {
   9 |     const loginPage = new LoginPage(page);
  10 |     await loginPage.goto();
  11 |     await loginPage.login(process.env.USERNAME!, process.env.PASSWORD!);
> 12 |     await expect(page).toHaveURL(/inventory/);
     |                        ^ Error: Timed out 5000ms waiting for expect(locator).toHaveURL(expected)
  13 |   });
  14 | });
  15 |
```