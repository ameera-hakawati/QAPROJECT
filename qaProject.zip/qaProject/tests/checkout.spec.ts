import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { ProductsPage } from '../pages/ProductsPage';
import { CartPage } from '../pages/CartPage';
import { CheckoutPage } from '../pages/CheckoutPage';
import * as dotenv from 'dotenv';

dotenv.config();

test('Checkout Process', async ({ page }) => {
  const loginPage = new LoginPage(page);
  const productsPage = new ProductsPage(page);
  const cartPage = new CartPage(page);
  const checkoutPage = new CheckoutPage(page);

  await loginPage.goto();
  await loginPage.login(process.env.USERNAME!, process.env.PASSWORD!);

  await productsPage.addToCart('Sauce Labs Bike Light');
  await productsPage.goToCart();
  await cartPage.checkout();

  await checkoutPage.enterInfo('John', 'Doe', '12345');
  await checkoutPage.finish();

  await expect(page.locator('.complete-header')).toHaveText('Thank you for your order!');
});
