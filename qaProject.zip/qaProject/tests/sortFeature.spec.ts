import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { ProductsPage } from '../pages/ProductsPage';
import * as dotenv from 'dotenv';

dotenv.config();

test.describe('Sort Feature', () => {
  test('Sort A-Z', async ({ page }) => {
    const loginPage = new LoginPage(page);
    const productsPage = new ProductsPage(page);

    await loginPage.goto();
    await loginPage.login(process.env.USERNAME!, process.env.PASSWORD!);

    await productsPage.sortAZ();
    await expect(page.locator('.active_option')).toHaveText('Name (A to Z)');
  });

  test('Sort Price High to Low', async ({ page }) => {
    const loginPage = new LoginPage(page);
    const productsPage = new ProductsPage(page);

    await loginPage.goto();
    await loginPage.login(process.env.USERNAME!, process.env.PASSWORD!);

    await productsPage.sortPriceHighToLow();
    await expect(page.locator('.active_option')).toHaveText('Price (high to low)');
  });
});
