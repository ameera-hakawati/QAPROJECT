import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { ProductsPage } from '../pages/ProductsPage';
import { CartPage } from '../pages/CartPage';
import * as dotenv from 'dotenv';

dotenv.config();

test('Remove from Cart', async ({ page }) => {
  const loginPage = new LoginPage(page);
  const productsPage = new ProductsPage(page);
  const cartPage = new CartPage(page);

  await loginPage.goto();
  await loginPage.login(process.env.USERNAME!, process.env.PASSWORD!);

  await productsPage.addToCart('Sauce Labs Backpack');
  await productsPage.goToCart();
  await cartPage.removeItem('Sauce Labs Backpack');

  await expect(page.locator('.cart_item')).toHaveCount(0);
});
