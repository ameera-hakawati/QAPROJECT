import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { ProductsPage } from '../pages/ProductsPage';
import * as dotenv from 'dotenv';

dotenv.config();

test('Add to Cart', async ({ page }) => {
  const loginPage = new LoginPage(page);
  const productsPage = new ProductsPage(page);

  await loginPage.goto();
  await loginPage.login(process.env.USERNAME!, process.env.PASSWORD!);

  await productsPage.addToCart('Sauce Labs Backpack');
  await productsPage.goToCart();

  await expect(page.locator('.cart_item')).toContainText('Sauce Labs Backpack');
});
