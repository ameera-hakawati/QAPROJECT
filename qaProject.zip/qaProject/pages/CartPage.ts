import { Page } from '@playwright/test';

export class CartPage {
  constructor(public page: Page) {}

  async checkout() {
    await this.page.click('button:has-text("Checkout")');
  }

  async removeItem(itemName: string) {
    await this.page.click(`button:has-text("Remove")`);
  }
}
