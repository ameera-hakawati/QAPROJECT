import { Page } from '@playwright/test';

export class ProductsPage {
  constructor(public page: Page) {}

  async addToCart(itemName: string) {
    await this.page.click(`text=${itemName}`);
    await this.page.click('button:has-text("Add to cart")');
  }

  async removeFromCart(itemName: string) {
    await this.page.click(`text=${itemName}`);
    await this.page.click('button:has-text("Remove")');
  }

  async sortAZ() {
    await this.page.selectOption('.product_sort_container', 'az');
  }

  async sortPriceHighToLow() {
    await this.page.selectOption('.product_sort_container', 'hilo');
  }

  async goToCart() {
    await this.page.click('.shopping_cart_link');
  }
}
